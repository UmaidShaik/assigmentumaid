package dogDoor.test;

import dogDoor.model.DogDoor;
import dogDoor.model.Remote;

public class DogDoorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DogDoor door = new DogDoor();      // create door
		Remote remote = new Remote(door);  // door ka remote  // open = false
		
		remote.pressButton();  // open = true
		
		remote.pressButton();  // open = false
		remote.pressButton();  // open = trues

	}

}
