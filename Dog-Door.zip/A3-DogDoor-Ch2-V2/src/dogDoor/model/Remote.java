package dogDoor.model;

import java.util.Timer;
import java.util.TimerTask;

public class Remote {
	
	private DogDoor door;
	
	public Remote(DogDoor door) {
		super();
		this.door = door;
	}
	
	public void pressButton() {
		if (!door.isOpen()) {
			door.open();
			Timer timer = new Timer();  
			timer.schedule(new TimerTask(){  // timer.schehule(*task Object*, *how much to wait before executing task object*)
				@Override
				public void run() {
					// TODO Auto-generated method stub
						door.close();
						timer.cancel(); 	
				}
			}, 5000);
		} else {
			door.close();
		}
	}

}
